PJRC rawhid code, adapted to build a DLL using the Microsoft Device Driver Kit (DDK).

The DDK version used was 3790.1830, obtained from:
http://download.microsoft.com/download/9/0/f/90f019ac-8243-48d3-91cf-81fc4093ecfd/1830_usa_ddk.iso

Original PJRC code can be found in PJRC_rawhid.
